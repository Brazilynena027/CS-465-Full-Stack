import { Authentication } from './authentication';

describe('Authentication', () => {
  it('should create an instance', () => {
    expect(new Authentication()).toBeTruthy();
  });
});
